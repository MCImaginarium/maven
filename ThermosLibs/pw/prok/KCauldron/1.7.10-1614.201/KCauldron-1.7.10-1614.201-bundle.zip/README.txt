KCauldron installation guide

# Understanding this bundle
You're reading this guide because you're using deprecated installation method
If you want use easier & safer method please read about KBootstrap at https://prok.pw/KBootstrap

# Installation and usage
1. Unpack this zip into server directory
2. Use following line to start the server:
  java -jar bin/pw/prok/KCauldron/1.7.10-1614.201/KCauldron-1.7.10-1614.201.jar
    ... or
  java -jar KCauldron.jar
3. That's end, enjoy

# Why I should use KBootstrap?
1. Easiest server installation
2. Built-in libraries management
3. Update & run server in one line
4. Ability to not read this boring guide
5. What else?
If you are not yet convinced and want to use bundles instead KBootstrap... Meh, this is your choice.
